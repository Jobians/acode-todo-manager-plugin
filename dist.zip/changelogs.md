## v1.0.0 (2025-09-04)
- Initial release of Todo Manager plugin for Acode.